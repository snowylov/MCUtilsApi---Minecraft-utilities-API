package com.yourname.modutils.api;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Item.Settings;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.LinkedHashMap;

public class AutoBlockRegistrar {
    private static final Map<String, Block> BLOCKS = new LinkedHashMap<>();

    public static void add(String name, Block block) {
        BLOCKS.put(name, block);
    }

    public static void registerAll(String namespace, Settings settings) {
        for (Map.Entry<String, Block> entry : BLOCKS.entrySet()) {
            Registry.register(Registries.BLOCK, new Identifier(namespace, entry.getKey()), entry.getValue());
            Registry.register(Registries.ITEM, new Identifier(namespace, entry.getKey()), new BlockItem(entry.getValue(), settings));
        }
    }
}