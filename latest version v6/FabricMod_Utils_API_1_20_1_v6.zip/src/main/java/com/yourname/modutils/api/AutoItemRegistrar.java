package com.yourname.modutils.api;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.LinkedHashMap;

public class AutoItemRegistrar {
    private static final Map<String, Item> ITEMS = new LinkedHashMap<>();

    public static void add(String name, Item item) {
        ITEMS.put(name, item);
    }

    public static void registerAll(String namespace) {
        for (Map.Entry<String, Item> entry : ITEMS.entrySet()) {
            Registry.register(Registries.ITEM, new Identifier(namespace, entry.getKey()), entry.getValue());
        }
    }
}