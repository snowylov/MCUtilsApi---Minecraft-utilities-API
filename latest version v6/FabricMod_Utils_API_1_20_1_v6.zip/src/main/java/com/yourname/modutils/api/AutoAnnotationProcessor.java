package com.yourname.modutils.api;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.function.BiConsumer;

public class AutoAnnotationProcessor {

    public static <A extends Annotation, T> void process(Class<?> cls, Class<A> annotationClass, BiConsumer<String, T> registrar) {
        for (Field field : cls.getDeclaredFields()) {
            if (field.isAnnotationPresent(annotationClass)) {
                try {
                    field.setAccessible(true);
                    A annotation = field.getAnnotation(annotationClass);
                    Object value = field.get(null); // static fields
                    registrar.accept(field.getName().toLowerCase(), (T) value);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}