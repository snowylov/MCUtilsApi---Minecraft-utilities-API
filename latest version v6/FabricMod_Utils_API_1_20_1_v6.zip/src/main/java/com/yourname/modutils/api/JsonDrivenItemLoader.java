package com.yourname.modutils.api;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterials;
import net.minecraft.item.SwordItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.HoeItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class JsonDrivenItemLoader {
    private static final Gson GSON = new Gson();

    public static class ItemDef {
        public String name;
        public String type = "item"; // item, sword, pickaxe, axe, shovel, hoe
        public int damage = 1;
        public float speed = 1.0f;
        public String material = "wood";
    }

    public static void registerFromJson(String modid) {
        try (InputStreamReader reader = new InputStreamReader(JsonDrivenItemLoader.class.getResourceAsStream("/assets/" + modid + "/json/items.json"))) {
            Type listType = new TypeToken<List<ItemDef>>(){}.getType();
            List<ItemDef> items = GSON.fromJson(reader, listType);

            for (ItemDef def : items) {
                Item item;
                switch (def.type) {
                    case "sword":
                        item = new SwordItem(ToolMaterials.valueOf(def.material.toUpperCase()), def.damage, def.speed, new Item.Settings());
                        break;
                    case "pickaxe":
                        item = new PickaxeItem(ToolMaterials.valueOf(def.material.toUpperCase()), def.damage, def.speed, new Item.Settings());
                        break;
                    case "axe":
                        item = new AxeItem(ToolMaterials.valueOf(def.material.toUpperCase()), def.damage, def.speed, new Item.Settings());
                        break;
                    case "shovel":
                        item = new ShovelItem(ToolMaterials.valueOf(def.material.toUpperCase()), def.damage, def.speed, new Item.Settings());
                        break;
                    case "hoe":
                        item = new HoeItem(ToolMaterials.valueOf(def.material.toUpperCase()), def.damage, def.speed, new Item.Settings());
                        break;
                    default:
                        item = new Item(new Item.Settings());
                }

                Registry.register(Registries.ITEM, new Identifier(modid, def.name), item);
            }
        } catch (Exception e) {
            System.err.println("Failed to load JSON items: " + e.getMessage());
        }
    }
}