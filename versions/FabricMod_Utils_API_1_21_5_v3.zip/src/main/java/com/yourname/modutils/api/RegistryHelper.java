package com.yourname.yourmod.util;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Item.Settings;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class RegistryHelper {
    public static <T extends Item> T registerItem(String name, T item) {
        return Registry.register(Registries.ITEM, ModUtil.id(name), item);
    }

    public static <T extends Block> T registerBlock(String name, T block, Settings settings) {
        Registry.register(Registries.BLOCK, ModUtil.id(name), block);
        registerItem(name, new BlockItem(block, settings));
        return block;
    }
}