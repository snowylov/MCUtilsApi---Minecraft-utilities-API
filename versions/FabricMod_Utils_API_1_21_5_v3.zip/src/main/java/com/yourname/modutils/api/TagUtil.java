package com.yourname.yourmod.util;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;

public class TagUtil {
    public static TagKey<Block> blockTag(String name) {
        return TagKey.of(RegistryKeys.BLOCK, ModUtil.id(name));
    }

    public static TagKey<Item> itemTag(String name) {
        return TagKey.of(RegistryKeys.ITEM, ModUtil.id(name));
    }
}