package com.yourname.yourmod.util;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.util.ActionResult;

public class EventBusHelper {
    public static void registerPlayerEvents() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            // Custom interaction logic
            return ActionResult.PASS;
        });
    }
}