package com.yourname.modutils.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;

public class LangEntryHelper {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, String> langMap = new HashMap<>();

    public static void addEntry(String key, String value) {
        langMap.put(key, value);
    }

    public static void save(String namespace) throws IOException {
        Path path = Paths.get("src/main/resources/assets/" + namespace + "/lang/en_us.json");
        Files.createDirectories(path.getParent());
        Files.writeString(path, GSON.toJson(langMap));
    }
}