package com.yourname.yourmod.util;

import net.minecraft.util.Identifier;

public class ModUtil {
    public static Identifier id(String path) {
        return new Identifier("yourmodid", path);
    }

    public static void log(String message) {
        System.out.println("[YourModID] " + message);
    }

    public static <T> T notNull(T value, String errorMsg) {
        if (value == null) throw new NullPointerException(errorMsg);
        return value;
    }
}