package com.yourname.yourmod.util;

import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.recipe.ShapelessRecipe;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.item.ItemStack;

public class RecipeHelper {
    public static ShapedRecipe shaped(String id, int width, int height, DefaultedList<Ingredient> ingredients, ItemStack output) {
        return new ShapedRecipe(ModUtil.id(id), "", width, height, ingredients, output);
    }

    public static ShapelessRecipe shapeless(String id, DefaultedList<Ingredient> ingredients, ItemStack output) {
        return new ShapelessRecipe(ModUtil.id(id), "", output, ingredients);
    }
}