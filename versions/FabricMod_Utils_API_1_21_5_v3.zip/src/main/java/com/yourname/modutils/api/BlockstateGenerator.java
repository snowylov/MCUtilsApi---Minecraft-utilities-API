package com.yourname.modutils.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.nio.file.*;

public class BlockstateGenerator {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void generateSimpleBlockstate(String name, String modelName) throws IOException {
        JsonObject variants = new JsonObject();
        JsonObject defaultVariant = new JsonObject();
        defaultVariant.addProperty("model", "yourmodid:block/" + modelName);
        variants.add("", defaultVariant);

        JsonObject blockstate = new JsonObject();
        blockstate.add("variants", variants);

        Path path = Paths.get("src/main/resources/assets/yourmodid/blockstates/" + name + ".json");
        Files.createDirectories(path.getParent());
        Files.writeString(path, GSON.toJson(blockstate));
    }
}