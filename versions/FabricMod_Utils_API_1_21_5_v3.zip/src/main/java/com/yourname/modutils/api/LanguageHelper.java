package com.yourname.yourmod.util;

import java.util.Map;
import java.util.HashMap;

public class LanguageHelper {
    private static final Map<String, String> EN_US = new HashMap<>();

    public static void add(String key, String value) {
        EN_US.put(key, value);
    }

    public static Map<String, String> getEntries() {
        return EN_US;
    }
}