package com.yourname.modutils.api;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.entity.Entity;
import net.minecraft.client.model.Model;

public class UniversalEntityRenderer<T extends Entity> extends EntityRenderer<T> {
    private final Model model;
    private final Identifier texture;

    public UniversalEntityRenderer(EntityRendererFactory.Context context, Model model, Identifier texture) {
        super(context);
        this.model = model;
        this.texture = texture;
    }

    @Override
    public void render(T entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        // Simple universal model rendering (basic, no animations)
        matrices.push();
        matrices.pop();
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }
}