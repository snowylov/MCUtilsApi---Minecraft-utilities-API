package com.yourname.modutils.api;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class EntityRegistryHelper {
    public static <T extends LivingEntity> EntityType<T> register(String name, EntityType<T> type, DefaultAttributeContainer attributes) {
        Identifier id = ModUtil.id(name);
        Registry.register(Registries.ENTITY_TYPE, id, type);
        FabricDefaultAttributeRegistry.register(type, attributes);
        return type;
    }
}