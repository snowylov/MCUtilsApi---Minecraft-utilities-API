package com.yourname.modutils.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.nio.file.*;

public class ModelRegistrationHelper {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void generateBlockModel(String name, String parent, String texture) throws IOException {
        JsonObject model = new JsonObject();
        model.addProperty("parent", parent);

        JsonObject textures = new JsonObject();
        textures.addProperty("all", texture);
        model.add("textures", textures);

        Path path = Paths.get("src/main/resources/assets/yourmodid/models/block/" + name + ".json");
        writeJson(path, model);
    }

    public static void generateItemModel(String name, String parent, String texture) throws IOException {
        JsonObject model = new JsonObject();
        model.addProperty("parent", parent);

        JsonObject textures = new JsonObject();
        textures.addProperty("layer0", texture);
        model.add("textures", textures);

        Path path = Paths.get("src/main/resources/assets/yourmodid/models/item/" + name + ".json");
        writeJson(path, model);
    }

    private static void writeJson(Path path, JsonObject content) throws IOException {
        Files.createDirectories(path.getParent());
        Files.writeString(path, GSON.toJson(content));
    }
}