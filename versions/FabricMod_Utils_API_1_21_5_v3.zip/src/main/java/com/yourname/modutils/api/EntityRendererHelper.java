package com.yourname.modutils.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.entity.EntityType;

@Environment(EnvType.CLIENT)
public class EntityRendererHelper {
    public static <T extends net.minecraft.entity.Entity> void registerRenderer(EntityType<T> entityType, EntityRendererFactory<T> factory) {
        EntityRendererRegistry.register(entityType, factory);
    }
}