package com.yourname.yourmod.util;

import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.util.Identifier;

public class LootTableHelper {
    public static LootTable simpleDropTable(String itemId) {
        LootPool pool = LootPool.builder()
            .rolls(ConstantLootNumberProvider.create(1))
            .with(ItemEntry.builder(ModUtil.id(itemId)))
            .build();
        return LootTable.builder().pool(pool).build();
    }
}