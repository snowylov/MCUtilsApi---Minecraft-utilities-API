package com.yourname.yourmod.util;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class CreativeTabHelper {
    public static ItemGroup createTab(String name, Item iconItem) {
        return FabricItemGroup.builder(ModUtil.id(name))
                .icon(() -> new ItemStack(iconItem))
                .build();
    }
}